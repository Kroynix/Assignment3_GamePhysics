int main()
{
	int Failed = 0;
	
	return Failed;
}

